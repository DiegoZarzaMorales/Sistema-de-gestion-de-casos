﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Bufete_de_abogados
{
    public partial class Form1 : Form
    {
        DataClasses1DataContext DB = new DataClasses1DataContext();
        public Form1()
        {
            InitializeComponent();
            toolTip1.SetToolTip(btnCrearexpediente, "Crear expediente");
            toolTip2.SetToolTip(btnDatosdelprodurador, "Ingresar datos del procurador");
            toolTip3.SetToolTip(btnDatosdelcaso, "Ingresar datos del caso");
            groupBox1.BackColor = Color.FromArgb(166, 57, 136, 236);
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }


        private void btnCrearexpediente_Click(object sender, EventArgs e)
        {

            Form2 CrearExpediente = new Form2();
            CrearExpediente.Show();
            this.Hide();

        }

        private void btnDatosdelprodurador_Click(object sender, EventArgs e)
        {

            Form3 AñadirProcurador = new Form3();
            AñadirProcurador.Show();
            this.Hide();
        }

        private void btnDatosdelcaso_Click(object sender, EventArgs e)
        {

            Form4 irform4 = new Form4();
            irform4.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear una conexión a la base de datos (ajusta la cadena de conexión según tu configuración)
                using (SqlConnection connection = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=NUEVO_GABINETE_DE_ABOGADOS;Integrated Security=True"))
                {
                    connection.Open();

                    // Crear un adaptador de datos
                    SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Asuntos", connection);

                    // Crear un DataTable para contener los datos
                    DataTable dataTable = new DataTable();

                    // Llenar el DataTable con los datos de la tabla
                    adapter.Fill(dataTable);

                    // Establecer el DataTable como fuente de datos del DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al mostrar los datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear una conexión a la base de datos (ajusta la cadena de conexión según tu configuración)
                using (SqlConnection connection = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=NUEVO_GABINETE_DE_ABOGADOS;Integrated Security=True"))
                {
                    connection.Open();

                    // Crear un adaptador de datos
                    SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Clientes", connection);

                    // Crear un DataTable para contener los datos
                    DataTable dataTable = new DataTable();

                    // Llenar el DataTable con los datos de la tabla
                    adapter.Fill(dataTable);

                    // Establecer el DataTable como fuente de datos del DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al mostrar los datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear una conexión a la base de datos (ajusta la cadena de conexión según tu configuración)
                using (SqlConnection connection = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=NUEVO_GABINETE_DE_ABOGADOS;Integrated Security=True"))
                {
                    connection.Open();

                    // Crear un adaptador de datos
                    SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Procuradores", connection);

                    // Crear un DataTable para contener los datos
                    DataTable dataTable = new DataTable();

                    // Llenar el DataTable con los datos de la tabla
                    adapter.Fill(dataTable);

                    // Establecer el DataTable como fuente de datos del DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al mostrar los datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Inicio regresrainicio = new Inicio();
            regresrainicio.Show();
            Close();
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_maximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btn_maximizar.Visible = false;
            btn_restaurar.Visible = true;
        }

        private void btn_restaurar_Click(object sender, EventArgs e)
        {
            this.WindowState=FormWindowState.Normal;
            btn_restaurar .Visible = false;
            btn_maximizar .Visible = true;
        }

        private void btn_minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState= FormWindowState.Minimized;
        }
    }
}
