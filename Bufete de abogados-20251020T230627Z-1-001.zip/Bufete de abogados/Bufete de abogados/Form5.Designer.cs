﻿namespace Bufete_de_abogados
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.Barra_Titulo = new System.Windows.Forms.Panel();
            this.btn_maximizar = new System.Windows.Forms.PictureBox();
            this.btn_minimizar = new System.Windows.Forms.PictureBox();
            this.btn_restaurar = new System.Windows.Forms.PictureBox();
            this.btn_cerrar = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCrearexpediente = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Menu_vertical = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnAsignaciondecasos = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnDatosdelabogado = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel_contenedor = new System.Windows.Forms.Panel();
            this.Barra_Titulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_maximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_restaurar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cerrar)).BeginInit();
            this.Menu_vertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Barra_Titulo
            // 
            this.Barra_Titulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(53)))), ((int)(((byte)(92)))));
            this.Barra_Titulo.Controls.Add(this.btn_maximizar);
            this.Barra_Titulo.Controls.Add(this.btn_minimizar);
            this.Barra_Titulo.Controls.Add(this.btn_restaurar);
            this.Barra_Titulo.Controls.Add(this.btn_cerrar);
            this.Barra_Titulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.Barra_Titulo.Location = new System.Drawing.Point(0, 0);
            this.Barra_Titulo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Barra_Titulo.Name = "Barra_Titulo";
            this.Barra_Titulo.Size = new System.Drawing.Size(1385, 34);
            this.Barra_Titulo.TabIndex = 0;
            this.Barra_Titulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Barra_Titulo_MouseDown);
            // 
            // btn_maximizar
            // 
            this.btn_maximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_maximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_maximizar.Image = global::Bufete_de_abogados.Properties.Resources.MinimizarMaximizarbotonTijjuanaLegalis;
            this.btn_maximizar.Location = new System.Drawing.Point(1318, 4);
            this.btn_maximizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_maximizar.Name = "btn_maximizar";
            this.btn_maximizar.Size = new System.Drawing.Size(25, 25);
            this.btn_maximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_maximizar.TabIndex = 8;
            this.btn_maximizar.TabStop = false;
            this.btn_maximizar.Click += new System.EventHandler(this.btn_maximizar_Click);
            // 
            // btn_minimizar
            // 
            this.btn_minimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_minimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_minimizar.Image = global::Bufete_de_abogados.Properties.Resources.MinimizarbotonTijjuanaLegalis;
            this.btn_minimizar.Location = new System.Drawing.Point(1287, 4);
            this.btn_minimizar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_minimizar.Name = "btn_minimizar";
            this.btn_minimizar.Size = new System.Drawing.Size(25, 25);
            this.btn_minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_minimizar.TabIndex = 7;
            this.btn_minimizar.TabStop = false;
            this.btn_minimizar.Click += new System.EventHandler(this.btn_minimizar_Click);
            // 
            // btn_restaurar
            // 
            this.btn_restaurar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_restaurar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_restaurar.Image = global::Bufete_de_abogados.Properties.Resources.MinimizarMaximizarbotonTijjuanaLegalis;
            this.btn_restaurar.Location = new System.Drawing.Point(1317, 4);
            this.btn_restaurar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_restaurar.Name = "btn_restaurar";
            this.btn_restaurar.Size = new System.Drawing.Size(25, 25);
            this.btn_restaurar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_restaurar.TabIndex = 6;
            this.btn_restaurar.TabStop = false;
            this.btn_restaurar.Visible = false;
            this.btn_restaurar.Click += new System.EventHandler(this.btn_restaurar_Click);
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cerrar.Image = global::Bufete_de_abogados.Properties.Resources.XbotonTijjuanaLegalis;
            this.btn_cerrar.Location = new System.Drawing.Point(1348, 4);
            this.btn_cerrar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(25, 25);
            this.btn_cerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_cerrar.TabIndex = 5;
            this.btn_cerrar.TabStop = false;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_cerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(90)))), ((int)(((byte)(100)))));
            this.label1.Location = new System.Drawing.Point(83, 208);
            this.label1.Margin = new System.Windows.Forms.Padding(40, 10, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cliente";
            // 
            // btnCrearexpediente
            // 
            this.btnCrearexpediente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(118)))), ((int)(((byte)(210)))));
            this.btnCrearexpediente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCrearexpediente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCrearexpediente.FlatAppearance.BorderSize = 0;
            this.btnCrearexpediente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.btnCrearexpediente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrearexpediente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrearexpediente.ForeColor = System.Drawing.Color.White;
            this.btnCrearexpediente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCrearexpediente.Location = new System.Drawing.Point(0, 242);
            this.btnCrearexpediente.Margin = new System.Windows.Forms.Padding(51, 10, 29, 2);
            this.btnCrearexpediente.Name = "btnCrearexpediente";
            this.btnCrearexpediente.Size = new System.Drawing.Size(253, 47);
            this.btnCrearexpediente.TabIndex = 0;
            this.btnCrearexpediente.Text = "Agregar cliente";
            this.btnCrearexpediente.UseVisualStyleBackColor = false;
            this.btnCrearexpediente.Click += new System.EventHandler(this.btnCrearexpediente_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(90)))), ((int)(((byte)(100)))));
            this.label2.Location = new System.Drawing.Point(71, 341);
            this.label2.Margin = new System.Windows.Forms.Padding(29, 10, 3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Abogado";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(90)))), ((int)(((byte)(100)))));
            this.label3.Location = new System.Drawing.Point(83, 466);
            this.label3.Margin = new System.Windows.Forms.Padding(29, 10, 3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Casos";
            // 
            // Menu_vertical
            // 
            this.Menu_vertical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(212)))), ((int)(((byte)(214)))));
            this.Menu_vertical.Controls.Add(this.panel4);
            this.Menu_vertical.Controls.Add(this.btnAsignaciondecasos);
            this.Menu_vertical.Controls.Add(this.panel3);
            this.Menu_vertical.Controls.Add(this.btnDatosdelabogado);
            this.Menu_vertical.Controls.Add(this.panel2);
            this.Menu_vertical.Controls.Add(this.pictureBox1);
            this.Menu_vertical.Controls.Add(this.label1);
            this.Menu_vertical.Controls.Add(this.btnCrearexpediente);
            this.Menu_vertical.Controls.Add(this.label3);
            this.Menu_vertical.Controls.Add(this.label2);
            this.Menu_vertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.Menu_vertical.Location = new System.Drawing.Point(0, 34);
            this.Menu_vertical.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Menu_vertical.Name = "Menu_vertical";
            this.Menu_vertical.Size = new System.Drawing.Size(253, 677);
            this.Menu_vertical.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.panel4.Location = new System.Drawing.Point(0, 501);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 47);
            this.panel4.TabIndex = 8;
            // 
            // btnAsignaciondecasos
            // 
            this.btnAsignaciondecasos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(118)))), ((int)(((byte)(210)))));
            this.btnAsignaciondecasos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAsignaciondecasos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAsignaciondecasos.FlatAppearance.BorderSize = 0;
            this.btnAsignaciondecasos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.btnAsignaciondecasos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAsignaciondecasos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsignaciondecasos.ForeColor = System.Drawing.Color.White;
            this.btnAsignaciondecasos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAsignaciondecasos.Location = new System.Drawing.Point(0, 501);
            this.btnAsignaciondecasos.Margin = new System.Windows.Forms.Padding(51, 10, 29, 2);
            this.btnAsignaciondecasos.Name = "btnAsignaciondecasos";
            this.btnAsignaciondecasos.Size = new System.Drawing.Size(253, 47);
            this.btnAsignaciondecasos.TabIndex = 7;
            this.btnAsignaciondecasos.Text = "Asignar caso";
            this.btnAsignaciondecasos.UseVisualStyleBackColor = false;
            this.btnAsignaciondecasos.Click += new System.EventHandler(this.btnAsignaciondecasos_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.panel3.Location = new System.Drawing.Point(0, 375);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 47);
            this.panel3.TabIndex = 6;
            // 
            // btnDatosdelabogado
            // 
            this.btnDatosdelabogado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(118)))), ((int)(((byte)(210)))));
            this.btnDatosdelabogado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDatosdelabogado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDatosdelabogado.FlatAppearance.BorderSize = 0;
            this.btnDatosdelabogado.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.btnDatosdelabogado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDatosdelabogado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatosdelabogado.ForeColor = System.Drawing.Color.White;
            this.btnDatosdelabogado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDatosdelabogado.Location = new System.Drawing.Point(0, 375);
            this.btnDatosdelabogado.Margin = new System.Windows.Forms.Padding(51, 10, 29, 2);
            this.btnDatosdelabogado.Name = "btnDatosdelabogado";
            this.btnDatosdelabogado.Size = new System.Drawing.Size(253, 47);
            this.btnDatosdelabogado.TabIndex = 5;
            this.btnDatosdelabogado.Text = "Registrar abogado";
            this.btnDatosdelabogado.UseVisualStyleBackColor = false;
            this.btnDatosdelabogado.Click += new System.EventHandler(this.btnDatosdelabogado_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(200)))));
            this.panel2.Location = new System.Drawing.Point(3, 242);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(5, 47);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(35, 5);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(29, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(189, 180);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel_contenedor
            // 
            this.panel_contenedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(131)))), ((int)(((byte)(133)))));
            this.panel_contenedor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_contenedor.BackgroundImage")));
            this.panel_contenedor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_contenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_contenedor.Location = new System.Drawing.Point(253, 34);
            this.panel_contenedor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_contenedor.Name = "panel_contenedor";
            this.panel_contenedor.Size = new System.Drawing.Size(1132, 677);
            this.panel_contenedor.TabIndex = 3;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1385, 711);
            this.Controls.Add(this.panel_contenedor);
            this.Controls.Add(this.Menu_vertical);
            this.Controls.Add(this.Barra_Titulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form5";
            this.Barra_Titulo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_maximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_restaurar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cerrar)).EndInit();
            this.Menu_vertical.ResumeLayout(false);
            this.Menu_vertical.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Barra_Titulo;
        private System.Windows.Forms.PictureBox btn_maximizar;
        private System.Windows.Forms.PictureBox btn_minimizar;
        private System.Windows.Forms.PictureBox btn_restaurar;
        private System.Windows.Forms.PictureBox btn_cerrar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCrearexpediente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel Menu_vertical;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnAsignaciondecasos;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDatosdelabogado;
        private System.Windows.Forms.Panel panel_contenedor;
    }
}