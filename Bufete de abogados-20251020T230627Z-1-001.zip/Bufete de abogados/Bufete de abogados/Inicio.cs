﻿using System;
using System.Windows.Forms;

namespace Bufete_de_abogados
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();

            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Creditos creditos = new Creditos();
            creditos.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();

            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
