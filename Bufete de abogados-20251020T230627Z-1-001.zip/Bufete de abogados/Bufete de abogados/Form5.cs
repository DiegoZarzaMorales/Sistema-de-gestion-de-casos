﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Bufete_de_abogados
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_maximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btn_maximizar.Visible = false;
            btn_restaurar.Visible = true;
        }

        private void btn_restaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btn_restaurar.Visible = false;
            btn_maximizar.Visible = true;
        }

        private void btn_minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

     

        //con  esto se mueve  la ventana 
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int IParam);

        private void Barra_Titulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        // Variable global para almacenar el formulario actual abierto
        private Form formularioActual = null;

        // Método para abrir o cerrar el formulario en el panel
        private void AbrirOcerrarFormularioEnPanel(Form formulario)
        {
            // Si el formulario que se quiere abrir ya está abierto, se cierra
            if (formularioActual != null && formularioActual.GetType() == formulario.GetType())
            {
                formularioActual.Close();
                formularioActual = null;
                return;
            }

            // Si hay un formulario ya abierto, se cierra
            if (this.panel_contenedor.Controls.Count > 0)
                this.panel_contenedor.Controls.RemoveAt(0);

            // Configurar el nuevo formulario y mostrarlo
            formulario.TopLevel = false;
            formulario.Dock = DockStyle.Fill;
            this.panel_contenedor.Controls.Add(formulario);
            this.panel_contenedor.Tag = formulario;
            formulario.Show();

            // Guardar la referencia al formulario actual
            formularioActual = formulario;
        }

        private void btnCrearexpediente_Click(object sender, EventArgs e)
        {
            AbrirOcerrarFormularioEnPanel(new Form2());
        }

        private void btnDatosdelabogado_Click(object sender, EventArgs e)
        {
            AbrirOcerrarFormularioEnPanel(new Form3());
        }

        private void btnAsignaciondecasos_Click(object sender, EventArgs e)
        {
            AbrirOcerrarFormularioEnPanel(new Form4());
        }

        private void btnFormularioActual_Click(object sender, EventArgs e)
        {
            // Abrir o cerrar el Form5 (tu formulario actual)
            AbrirOcerrarFormularioEnPanel(new Form5());
        }
    }
}
