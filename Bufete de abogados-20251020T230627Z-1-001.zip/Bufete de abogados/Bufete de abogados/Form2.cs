﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Bufete_de_abogados
{
    public partial class Form2 : Form
    {
        DataClasses1DataContext DB = new DataClasses1DataContext();
        public Form2()
        {
            InitializeComponent();
            actualizar();
            toolTip1.SetToolTip(btn_Guardar, "Guardar");
            toolTip2.SetToolTip(btnModificarexpediente, "Modificar Expediente");
            toolTip3.SetToolTip(btnBorrarexpediente, "Borrar Expediente");
            panel1.BackColor = Color.FromArgb(166, 57, 136, 236);
            Estilo();
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {

            // Validar que los campos no estén vacíos
            if (string.IsNullOrWhiteSpace(txtDNI.Text))
            {
                MessageBox.Show("El campo DNI no puede estar vacío.");
                return;
            }
            if (txtDNI.Text.Length != 10)
            {
                MessageBox.Show("El campo DNI debe tener exactamente 10 caracteres.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El campo Nombre no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtApellido.Text))
            {
                MessageBox.Show("El campo Apellido no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtDomicilio.Text))
            {
                MessageBox.Show("El campo Domicilio no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTelefono.Text) || !txtTelefono.Text.All(char.IsDigit))
            {
                MessageBox.Show("El campo Teléfono debe contener solo números.");
                return ;
            }
            if (txtTelefono.Text.Length != 10)
            {
                MessageBox.Show("El campo Teléfono debe tener exactamente 10 dígitos.");
                return ;
            }
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtNombre.Text, @"^[a-zA-Z]+$"))
            {
                MessageBox.Show("El campo de nombre solo acepta letras");
                return;
            }
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtApellido.Text, @"^[a-zA-Z]+$"))
            {
                MessageBox.Show("El campo de apellido solo acepta letras");
                return;
            }


            DB.ingresar_clientes(txtDNI.Text, txtNombre.Text, txtApellido.Text, txtDomicilio.Text, txtTelefono.Text);
            actualizar();
        }

        private void btn_Consultar_Click(object sender, EventArgs e)
        {
            DB.LEER_ingresar_clientess();
        }

        private void btnModificarexpediente_Click(object sender, EventArgs e)
        {
            // Asegúrate de que txtDNI tenga el DNI del cliente que deseas actualizar
            //DB.ActualizarCliente();

            // Validar los campos como se hizo anteriormente
            if (string.IsNullOrWhiteSpace(txtDNI.Text))
            {
                MessageBox.Show("El campo DNI no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El campo Nombre no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtApellido.Text))
            {
                MessageBox.Show("El campo Apellido no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtDomicilio.Text))
            {
                MessageBox.Show("El campo Domicilio no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTelefono.Text) || !txtTelefono.Text.All(char.IsDigit))
            {
                MessageBox.Show("El campo Teléfono debe contener solo números y no puede estar vacío.");
                return;
            }

            DB.ActualizarCliente(txtDNI.Text,txtNombre.Text, txtApellido.Text, txtDomicilio.Text, txtTelefono.Text);
            actualizar();
        }

        private void btnBorrarexpediente_Click(object sender, EventArgs e)
        {
            DB.Borrar_ingresar_clientes(txtDNI.Text);
            actualizar();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'nUEVO_GABINETE_DE_ABOGADOSDataSet.Clientes' Puede moverla o quitarla según sea necesario.
            //this.clientesTableAdapter.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet.Clientes);

        }

        void actualizar()
        {
            this.clientesTableAdapter.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet.Clientes);

        }

        private void Estilo()
        {
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Centrar encabezados
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold); // Negritas en encabezados
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = ColorTranslator.FromHtml("#212121"); // Color de texto de encabezados
            dataGridView1.EnableHeadersVisualStyles = false; // Desactivar estilos visuales para aplicar el estilo personalizado
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#F5F5F5"); // Color de fondo de encabezados

            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
            Form1 regresraform1 = new Form1();
            regresraform1.Show();
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                // Aquí puedes acceder a la fila seleccionada y realizar acciones en función de la fila.
                // Por ejemplo, puedes obtener el valor de una celda de la fila: selectedRow.Cells["NombreDeLaColumna"].Value

                txtDNI.Text = selectedRow.Cells[0].Value.ToString();
                txtNombre.Text = selectedRow.Cells[1].Value.ToString();
                txtApellido.Text = selectedRow.Cells[2].Value.ToString();
                txtDomicilio.Text = selectedRow.Cells[3].Value.ToString();
                txtTelefono.Text = selectedRow.Cells[4].Value.ToString();
            }
        }

        

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verifica si la tecla presionada es un número o la tecla de retroceso (Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;  // Cancela la entrada si no es un número
            }
        }

        private void txtDNI_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verifica si la tecla presionada es un número o la tecla de retroceso (Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;  // Cancela la entrada si no es un número
            }
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDomicilio_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
