﻿namespace Bufete_de_abogados
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.label5 = new System.Windows.Forms.Label();
            this.txtDNI = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFechadeinicio = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFechafinal = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dNIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaInicioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaFinalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datosCasoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.asuntosBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet16 = new Bufete_de_abogados.NUEVO_GABINETE_DE_ABOGADOSDataSet16();
            this.asuntosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet13 = new Bufete_de_abogados.NUEVO_GABINETE_DE_ABOGADOSDataSet13();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.asuntosTableAdapter = new Bufete_de_abogados.NUEVO_GABINETE_DE_ABOGADOSDataSet13TableAdapters.AsuntosTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnasignarabogado = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDatodelcaso = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxEstado = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnborrarexpediente = new System.Windows.Forms.Button();
            this.btnModificardatosdelcaso = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.asuntosTableAdapter1 = new Bufete_de_abogados.NUEVO_GABINETE_DE_ABOGADOSDataSet16TableAdapters.AsuntosTableAdapter();
            this.label11 = new System.Windows.Forms.Label();
            this.ProcuradorIDtxt = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.asuntosBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUEVO_GABINETE_DE_ABOGADOSDataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.asuntosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUEVO_GABINETE_DE_ABOGADOSDataSet13)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 11);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(193, 29);
            this.label5.TabIndex = 66;
            this.label5.Text = "ID del caso (DNI)";
            // 
            // txtDNI
            // 
            this.txtDNI.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11.89565F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDNI.Location = new System.Drawing.Point(12, 44);
            this.txtDNI.Margin = new System.Windows.Forms.Padding(4);
            this.txtDNI.Name = "txtDNI";
            this.txtDNI.Size = new System.Drawing.Size(289, 33);
            this.txtDNI.TabIndex = 65;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 696);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 29);
            this.label4.TabIndex = 64;
            this.label4.Text = "Estado";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 765);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 29);
            this.label3.TabIndex = 62;
            this.label3.Text = "Fecha inicio";
            // 
            // txtFechadeinicio
            // 
            this.txtFechadeinicio.Location = new System.Drawing.Point(14, 798);
            this.txtFechadeinicio.Margin = new System.Windows.Forms.Padding(4);
            this.txtFechadeinicio.Name = "txtFechadeinicio";
            this.txtFechadeinicio.Size = new System.Drawing.Size(244, 22);
            this.txtFechadeinicio.TabIndex = 61;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 840);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 29);
            this.label2.TabIndex = 60;
            this.label2.Text = "Fecha final";
            // 
            // txtFechafinal
            // 
            this.txtFechafinal.Location = new System.Drawing.Point(14, 873);
            this.txtFechafinal.Margin = new System.Windows.Forms.Padding(4);
            this.txtFechafinal.Name = "txtFechafinal";
            this.txtFechafinal.Size = new System.Drawing.Size(244, 22);
            this.txtFechafinal.TabIndex = 59;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dNIDataGridViewTextBoxColumn,
            this.fechaInicioDataGridViewTextBoxColumn,
            this.fechaFinalDataGridViewTextBoxColumn,
            this.estadoDataGridViewTextBoxColumn,
            this.datosCasoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.asuntosBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(352, 173);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(737, 918);
            this.dataGridView1.TabIndex = 75;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // dNIDataGridViewTextBoxColumn
            // 
            this.dNIDataGridViewTextBoxColumn.DataPropertyName = "DNI";
            this.dNIDataGridViewTextBoxColumn.HeaderText = "DNI";
            this.dNIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dNIDataGridViewTextBoxColumn.Name = "dNIDataGridViewTextBoxColumn";
            // 
            // fechaInicioDataGridViewTextBoxColumn
            // 
            this.fechaInicioDataGridViewTextBoxColumn.DataPropertyName = "FechaInicio";
            this.fechaInicioDataGridViewTextBoxColumn.HeaderText = "FechaInicio";
            this.fechaInicioDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.fechaInicioDataGridViewTextBoxColumn.Name = "fechaInicioDataGridViewTextBoxColumn";
            // 
            // fechaFinalDataGridViewTextBoxColumn
            // 
            this.fechaFinalDataGridViewTextBoxColumn.DataPropertyName = "FechaFinal";
            this.fechaFinalDataGridViewTextBoxColumn.HeaderText = "FechaFinal";
            this.fechaFinalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.fechaFinalDataGridViewTextBoxColumn.Name = "fechaFinalDataGridViewTextBoxColumn";
            // 
            // estadoDataGridViewTextBoxColumn
            // 
            this.estadoDataGridViewTextBoxColumn.DataPropertyName = "Estado";
            this.estadoDataGridViewTextBoxColumn.HeaderText = "Estado";
            this.estadoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.estadoDataGridViewTextBoxColumn.Name = "estadoDataGridViewTextBoxColumn";
            // 
            // datosCasoDataGridViewTextBoxColumn
            // 
            this.datosCasoDataGridViewTextBoxColumn.DataPropertyName = "DatosCaso";
            this.datosCasoDataGridViewTextBoxColumn.HeaderText = "DatosCaso";
            this.datosCasoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.datosCasoDataGridViewTextBoxColumn.Name = "datosCasoDataGridViewTextBoxColumn";
            // 
            // asuntosBindingSource1
            // 
            this.asuntosBindingSource1.DataMember = "Asuntos";
            this.asuntosBindingSource1.DataSource = this.nUEVO_GABINETE_DE_ABOGADOSDataSet16;
            // 
            // nUEVO_GABINETE_DE_ABOGADOSDataSet16
            // 
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet16.DataSetName = "NUEVO_GABINETE_DE_ABOGADOSDataSet16";
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // asuntosBindingSource
            // 
            this.asuntosBindingSource.DataMember = "Asuntos";
            this.asuntosBindingSource.DataSource = this.nUEVO_GABINETE_DE_ABOGADOSDataSet13;
            // 
            // nUEVO_GABINETE_DE_ABOGADOSDataSet13
            // 
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet13.DataSetName = "NUEVO_GABINETE_DE_ABOGADOSDataSet13";
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(14, 798);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(289, 30);
            this.dateTimePicker1.TabIndex = 76;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(14, 873);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(289, 30);
            this.dateTimePicker2.TabIndex = 77;
            // 
            // asuntosTableAdapter
            // 
            this.asuntosTableAdapter.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(136)))), ((int)(((byte)(236)))));
            this.panel1.Controls.Add(this.ProcuradorIDtxt);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.btnasignarabogado);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.txtDatodelcaso);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.comboBoxEstado);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.txtDNI);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtFechadeinicio);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtFechafinal);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(15, 162);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(328, 929);
            this.panel1.TabIndex = 78;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnasignarabogado
            // 
            this.btnasignarabogado.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnasignarabogado.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnasignarabogado.BackgroundImage = global::Bufete_de_abogados.Properties.Resources._3729;
            this.btnasignarabogado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnasignarabogado.Location = new System.Drawing.Point(96, 617);
            this.btnasignarabogado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnasignarabogado.Name = "btnasignarabogado";
            this.btnasignarabogado.Size = new System.Drawing.Size(90, 68);
            this.btnasignarabogado.TabIndex = 93;
            this.btnasignarabogado.UseVisualStyleBackColor = false;
            this.btnasignarabogado.Click += new System.EventHandler(this.btnasignarabogado_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 572);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(195, 29);
            this.label10.TabIndex = 92;
            this.label10.Text = "Asignar abogado";
            // 
            // txtDatodelcaso
            // 
            this.txtDatodelcaso.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11.89565F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDatodelcaso.Location = new System.Drawing.Point(13, 114);
            this.txtDatodelcaso.Margin = new System.Windows.Forms.Padding(4);
            this.txtDatodelcaso.Multiline = true;
            this.txtDatodelcaso.Name = "txtDatodelcaso";
            this.txtDatodelcaso.Size = new System.Drawing.Size(288, 329);
            this.txtDatodelcaso.TabIndex = 90;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 81);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 29);
            this.label1.TabIndex = 89;
            this.label1.Text = "Datos del caso ";
            // 
            // comboBoxEstado
            // 
            this.comboBoxEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxEstado.FormattingEnabled = true;
            this.comboBoxEstado.Location = new System.Drawing.Point(14, 725);
            this.comboBoxEstado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxEstado.Name = "comboBoxEstado";
            this.comboBoxEstado.Size = new System.Drawing.Size(287, 33);
            this.comboBoxEstado.TabIndex = 88;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(248, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(239, 46);
            this.label6.TabIndex = 86;
            this.label6.Text = "Modificar \r\ndatos del caso";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(493, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(241, 46);
            this.label7.TabIndex = 85;
            this.label7.Text = "Eliminar \r\ndatos del caso";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(239, 23);
            this.label8.TabIndex = 84;
            this.label8.Text = "Guardar";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnborrarexpediente, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnModificardatosdelcaso, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnGuardar, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(352, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.05882F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.94118F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(737, 135);
            this.tableLayoutPanel1.TabIndex = 87;
            // 
            // btnborrarexpediente
            // 
            this.btnborrarexpediente.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnborrarexpediente.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnborrarexpediente.BackgroundImage = global::Bufete_de_abogados.Properties.Resources._32218451;
            this.btnborrarexpediente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnborrarexpediente.Location = new System.Drawing.Point(581, 68);
            this.btnborrarexpediente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnborrarexpediente.Name = "btnborrarexpediente";
            this.btnborrarexpediente.Size = new System.Drawing.Size(65, 62);
            this.btnborrarexpediente.TabIndex = 72;
            this.btnborrarexpediente.UseVisualStyleBackColor = false;
            this.btnborrarexpediente.Click += new System.EventHandler(this.btnborrarexpediente_Click);
            // 
            // btnModificardatosdelcaso
            // 
            this.btnModificardatosdelcaso.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnModificardatosdelcaso.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnModificardatosdelcaso.BackgroundImage = global::Bufete_de_abogados.Properties.Resources.create_edit_modify_icon_176960;
            this.btnModificardatosdelcaso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnModificardatosdelcaso.Location = new System.Drawing.Point(335, 68);
            this.btnModificardatosdelcaso.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnModificardatosdelcaso.Name = "btnModificardatosdelcaso";
            this.btnModificardatosdelcaso.Size = new System.Drawing.Size(65, 62);
            this.btnModificardatosdelcaso.TabIndex = 71;
            this.btnModificardatosdelcaso.UseVisualStyleBackColor = false;
            this.btnModificardatosdelcaso.Click += new System.EventHandler(this.btnModificardatosdelcaso_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGuardar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnGuardar.BackgroundImage = global::Bufete_de_abogados.Properties.Resources._14862;
            this.btnGuardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGuardar.Location = new System.Drawing.Point(90, 70);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(65, 58);
            this.btnGuardar.TabIndex = 68;
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 15F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(164, 15);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 66);
            this.label9.TabIndex = 96;
            this.label9.Text = "Datos \r\ndel caso";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(15, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(147, 124);
            this.pictureBox1.TabIndex = 79;
            this.pictureBox1.TabStop = false;
            // 
            // asuntosTableAdapter1
            // 
            this.asuntosTableAdapter1.ClearBeforeFill = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(14, 457);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(202, 29);
            this.label11.TabIndex = 94;
            this.label11.Text = "ID del procurador";
            // 
            // ProcuradorIDtxt
            // 
            this.ProcuradorIDtxt.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11.89565F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProcuradorIDtxt.Location = new System.Drawing.Point(12, 499);
            this.ProcuradorIDtxt.Margin = new System.Windows.Forms.Padding(4);
            this.ProcuradorIDtxt.Name = "ProcuradorIDtxt";
            this.ProcuradorIDtxt.Size = new System.Drawing.Size(289, 33);
            this.ProcuradorIDtxt.TabIndex = 95;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(104)))), ((int)(((byte)(152)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1105, 1102);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tijuana Legalis - Datos del Caso";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.asuntosBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUEVO_GABINETE_DE_ABOGADOSDataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.asuntosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUEVO_GABINETE_DE_ABOGADOSDataSet13)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDNI;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFechadeinicio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFechafinal;
        private System.Windows.Forms.Button btnModificardatosdelcaso;
        private System.Windows.Forms.Button btnborrarexpediente;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private NUEVO_GABINETE_DE_ABOGADOSDataSet13 nUEVO_GABINETE_DE_ABOGADOSDataSet13;
        private System.Windows.Forms.BindingSource asuntosBindingSource;
        private NUEVO_GABINETE_DE_ABOGADOSDataSet13TableAdapters.AsuntosTableAdapter asuntosTableAdapter;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.ToolTip toolTip4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxEstado;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDatodelcaso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnasignarabogado;
        private System.Windows.Forms.Label label10;
        private NUEVO_GABINETE_DE_ABOGADOSDataSet16 nUEVO_GABINETE_DE_ABOGADOSDataSet16;
        private System.Windows.Forms.BindingSource asuntosBindingSource1;
        private NUEVO_GABINETE_DE_ABOGADOSDataSet16TableAdapters.AsuntosTableAdapter asuntosTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dNIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaInicioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaFinalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datosCasoDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox ProcuradorIDtxt;
        private System.Windows.Forms.Label label11;
    }
}