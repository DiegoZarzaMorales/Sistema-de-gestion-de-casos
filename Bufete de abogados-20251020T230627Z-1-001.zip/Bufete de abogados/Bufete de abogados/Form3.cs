﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Bufete_de_abogados
{
    public partial class Form3 : Form
    {
        DataClasses1DataContext DB = new DataClasses1DataContext();
        public Form3()
        {
            InitializeComponent();
            actualizar();
            toolTip1.SetToolTip(btn_Guardar, "Guardar");
            toolTip2.SetToolTip(btnModificarexpediente, "Modificar Expediente");
            toolTip3.SetToolTip(btnBorrarexpediente, "Borrar datos del procurador");
            panel1.BackColor = Color.FromArgb(166, 57, 136, 236);
            Estilo();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'nUEVO_GABINETE_DE_ABOGADOSDataSet1.Procuradores' Puede moverla o quitarla según sea necesario.
            //            this.procuradoresTableAdapter.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet1.Procuradores);

        }

        void actualizar()
        {
            this.procuradoresTableAdapter.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet1.Procuradores);

        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                // Aquí puedes acceder a la fila seleccionada y realizar acciones en función de la fila.
                // Por ejemplo, puedes obtener el valor de una celda de la fila: selectedRow.Cells["NombreDeLaColumna"].Value
                txtIDprocurador.Text = selectedRow.Cells[0].Value.ToString();
                txtNombre.Text = selectedRow.Cells[1].Value.ToString();
                txtApellido.Text = selectedRow.Cells[2].Value.ToString();
                txtCorreo.Text = selectedRow.Cells[3].Value.ToString();
                txtTelefono.Text = selectedRow.Cells[4].Value.ToString();


            }
        }

        private void Estilo()
        {
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Centrar encabezados
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold); // Negritas en encabezados
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = ColorTranslator.FromHtml("#212121"); // Color de texto de encabezados
            dataGridView1.EnableHeadersVisualStyles = false; // Desactivar estilos visuales para aplicar el estilo personalizado
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#F5F5F5"); // Color de fondo de encabezados

            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }


        private void txtIDprocurador_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verifica si la tecla presionada es un número o la tecla de retroceso (Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;  // Cancela la entrada si no es un número
            }
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verifica si la tecla presionada es un número o la tecla de retroceso (Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;  // Cancela la entrada si no es un número
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            // Validar que los campos no estén vacíos
            if (string.IsNullOrWhiteSpace(txtIDprocurador.Text))
            {
                MessageBox.Show("El campo ID no puede estar vacío.");
                return;
            }
            if (txtIDprocurador.Text.Length != 10)
            {
                MessageBox.Show("El campo ID debe tener exactamente 10 caracteres.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTelefono.Text) || !txtTelefono.Text.All(char.IsDigit))
            {
                MessageBox.Show("El campo Teléfono debe contener solo números.");
                return;
            }
            if (txtTelefono.Text.Length != 10)
            {
                MessageBox.Show("El campo Teléfono debe tener exactamente 10 dígitos.");
                return;
            }
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtNombre.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("El campo de nombre solo acepta letras");
                return;
            }
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtApellido.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("El campo de apellido solo acepta letras");
                return;
            }
            if (!txtCorreo.Text.Contains("@"))
            {
                MessageBox.Show("El correo debe contener un '@'.");
                return;
            }


            DB.ingresar_Procuradores(txtIDprocurador.Text, txtNombre.Text, txtApellido.Text, txtCorreo.Text, txtTelefono.Text);
            actualizar();

        }

        private void btnModificarexpediente_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El campo nombre no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtApellido.Text))
            {
                MessageBox.Show("El campo apellido no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCorreo.Text))
            {
                MessageBox.Show("El campo correo no puede estar vacío.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                MessageBox.Show("El campo telefono no puede estar vacío.");
                return;
            }

            DB.ActualizarProcurador(txtIDprocurador.Text, txtNombre.Text, txtApellido.Text, txtCorreo.Text, txtTelefono.Text);
            actualizar();
        }

        private void btnBorrarexpediente_Click(object sender, EventArgs e)
        {
            DB.Borrar_Procuradores(txtIDprocurador.Text);
            actualizar();
        }
    }
}
