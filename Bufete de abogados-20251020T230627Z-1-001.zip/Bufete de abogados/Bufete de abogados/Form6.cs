﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Bufete_de_abogados
{
    public partial class Form6 : Form
    {
        private readonly DataClasses1DataContext db;

        public Form6()
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            ConfigurarDataGridView();
            ActualizarDatos();
        }

        private void ConfigurarDataGridView()
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.MultiSelect = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(busquedapornombretxt.Text))
                {
                    MessageBox.Show("Por favor ingrese un nombre para buscar.",
                                  "Advertencia",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Warning);
                    return;
                }

                // Usar el procedimiento almacenado mediante LINQ to SQL
                var resultados = db.BuscarProcuradoresPorNombre(busquedapornombretxt.Text).ToList();
                if (resultados.Count == 0)
                {
                    MessageBox.Show("No se encontraron procuradores con ese nombre.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    dataGridView1.DataSource = resultados;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar procuradores: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }

        }

        private void ActualizarDatos()
        {
            try
            {
                // Mostrar todos los procuradores
                var todosLosProcuradores = db.Procuradores.ToList();
                dataGridView1.DataSource = todosLosProcuradores;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica que la fila seleccionada sea válida
            if (e.RowIndex >= 0)
            {
                // Obtener la fila seleccionada
                var filaSeleccionada = dataGridView1.Rows[e.RowIndex];

                // Supongamos que la columna de ProcuradorID es la primera (índice 0)
                // Cambia el índice según la posición de tu columna
                var procuradorID = filaSeleccionada.Cells[0].Value; // Cambia el índice según corresponda

                // Guardar el ProcuradorID en el TextBox
                procuradorIdTextBox.Text = procuradorID.ToString();// este comentario tiene que estar para que el error se quite 
            }
        }
    }
}