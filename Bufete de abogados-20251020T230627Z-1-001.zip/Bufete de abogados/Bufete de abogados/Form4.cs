﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Bufete_de_abogados
{
    public partial class Form4 : Form
    {
        DataClasses1DataContext DB = new DataClasses1DataContext();
        public Form4()
        {
            InitializeComponent();
            //actualizar();
            toolTip1.SetToolTip(btnGuardar, "Guardar");
            toolTip2.SetToolTip(btnModificardatosdelcaso, "Modificar Datos del Caso");
            toolTip3.SetToolTip(btnborrarexpediente, "Borrar Expediente");
            panel1.BackColor = Color.FromArgb(166, 57, 136, 236);

            // Configurar el ComboBox
            comboBoxEstado.Items.Add("Divorcio");
            comboBoxEstado.Items.Add("Pencion alimenticia");
            comboBoxEstado.Items.Add("Custodia");
            Estilo();
        }

        public void SetProcuradorID(string procuradorID)
        {
            ProcuradorIDtxt.Text = procuradorID;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

            // Validar que los campos no estén vacíos
            if (string.IsNullOrWhiteSpace(txtDNI.Text))
            {
                MessageBox.Show("El campo ID no puede estar vacío.");
                return;
            }
            if (txtDNI.Text.Length != 10)
            {
                MessageBox.Show("El campo ID debe tener exactamente 10 caracteres.");
                return;
            }

            DB.ingresar_Asuntos(txtDNI.Text, dateTimePicker2.Value, dateTimePicker1.Value, comboBoxEstado.SelectedItem.ToString(), txtDatodelcaso.Text);
            actualizar();
        }

        private void btnModificardatosdelcaso_Click(object sender, EventArgs e)
        {

            DB.ActualizarAsunto(dateTimePicker2.Value, dateTimePicker1.Value, comboBoxEstado.SelectedItem.ToString(), txtDatodelcaso.Text);
            actualizar();
        }

        private void btnborrarexpediente_Click(object sender, EventArgs e)
        {
            DB.Borrar_Cliente_y_Asuntos(txtDNI.Text);
            actualizar();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
            Form1 regresraform1 = new Form1();
            regresraform1.Show();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'nUEVO_GABINETE_DE_ABOGADOSDataSet16.Asuntos' Puede moverla o quitarla según sea necesario.
            this.asuntosTableAdapter1.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet16.Asuntos);
            // TODO: esta línea de código carga datos en la tabla 'nUEVO_GABINETE_DE_ABOGADOSDataSet13.Asuntos' Puede moverla o quitarla según sea necesario.
            // this.asuntosTableAdapter.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet13.Asuntos);
            // TODO: esta línea de código carga datos en la tabla 'nUEVO_GABINETE_DE_ABOGADOSDataSet12.Asuntos' Puede moverla o quitarla según sea necesario.
            //this.asuntosTableAdapter.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet12.Asuntos);
        }
        void actualizar()
        {

            //this.asuntosTableAdapter.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet13.Asuntos);
            this.asuntosTableAdapter1.Fill(this.nUEVO_GABINETE_DE_ABOGADOSDataSet16.Asuntos);

        }

        private void Estilo()
        {
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Centrar encabezados
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold); // Negritas en encabezados
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = ColorTranslator.FromHtml("#212121"); // Color de texto de encabezados
            dataGridView1.EnableHeadersVisualStyles = false; // Desactivar estilos visuales para aplicar el estilo personalizado
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#F5F5F5"); // Color de fondo de encabezados

            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                // Aquí puedes acceder a la fila seleccionada y realizar acciones en función de la fila.
                // Por ejemplo, puedes obtener el valor de una celda de la fila: selectedRow.Cells["NombreDeLaColumna"].Value

                txtDNI.Text = selectedRow.Cells[0].Value.ToString();
                dateTimePicker2.Value = (DateTime)selectedRow.Cells[1].Value;
                dateTimePicker1.Value = (DateTime)selectedRow.Cells[2].Value;
                //txtEstado.Text = selectedRow.Cells[3].Value.ToString();
                // Configurar el ComboBox con el valor de la celda
                comboBoxEstado.SelectedItem = selectedRow.Cells[3].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
            Form1 regresraform1 = new Form1();
            regresraform1.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnasignarabogado_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
        }
    }
}
