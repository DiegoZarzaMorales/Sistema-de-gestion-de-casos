﻿namespace Bufete_de_abogados
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing && (components != null))
        //    {
        //        components.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.procuradorIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoProcuradorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.procuradoresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet14 = new Bufete_de_abogados.NUEVO_GABINETE_DE_ABOGADOSDataSet14();
            this.label11 = new System.Windows.Forms.Label();
            this.txtIDprocurador = new System.Windows.Forms.TextBox();
            this.procuradoresTableAdapter = new Bufete_de_abogados.NUEVO_GABINETE_DE_ABOGADOSDataSet14TableAdapters.ProcuradoresTableAdapter();
            this.busquedapornombretxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.procuradorIdTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.procuradoresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUEVO_GABINETE_DE_ABOGADOSDataSet14)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.procuradorIDDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn,
            this.apellidoDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.telefonoProcuradorDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.procuradoresBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(115, 195);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(676, 431);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // procuradorIDDataGridViewTextBoxColumn
            // 
            this.procuradorIDDataGridViewTextBoxColumn.DataPropertyName = "ProcuradorID";
            this.procuradorIDDataGridViewTextBoxColumn.HeaderText = "ProcuradorID";
            this.procuradorIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.procuradorIDDataGridViewTextBoxColumn.Name = "procuradorIDDataGridViewTextBoxColumn";
            this.procuradorIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            this.nombreDataGridViewTextBoxColumn.Width = 125;
            // 
            // apellidoDataGridViewTextBoxColumn
            // 
            this.apellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.HeaderText = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.apellidoDataGridViewTextBoxColumn.Name = "apellidoDataGridViewTextBoxColumn";
            this.apellidoDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // telefonoProcuradorDataGridViewTextBoxColumn
            // 
            this.telefonoProcuradorDataGridViewTextBoxColumn.DataPropertyName = "TelefonoProcurador";
            this.telefonoProcuradorDataGridViewTextBoxColumn.HeaderText = "TelefonoProcurador";
            this.telefonoProcuradorDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.telefonoProcuradorDataGridViewTextBoxColumn.Name = "telefonoProcuradorDataGridViewTextBoxColumn";
            this.telefonoProcuradorDataGridViewTextBoxColumn.Width = 125;
            // 
            // procuradoresBindingSource
            // 
            this.procuradoresBindingSource.DataMember = "Procuradores";
            this.procuradoresBindingSource.DataSource = this.nUEVO_GABINETE_DE_ABOGADOSDataSet14;
            // 
            // nUEVO_GABINETE_DE_ABOGADOSDataSet14
            // 
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet14.DataSetName = "NUEVO_GABINETE_DE_ABOGADOSDataSet14";
            this.nUEVO_GABINETE_DE_ABOGADOSDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(336, 9);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(205, 29);
            this.label11.TabIndex = 52;
            this.label11.Text = "Lista de abogados";
            // 
            // txtIDprocurador
            // 
            this.txtIDprocurador.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11.89565F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDprocurador.Location = new System.Drawing.Point(14, 64);
            this.txtIDprocurador.Margin = new System.Windows.Forms.Padding(4);
            this.txtIDprocurador.Name = "txtIDprocurador";
            this.txtIDprocurador.Size = new System.Drawing.Size(289, 33);
            this.txtIDprocurador.TabIndex = 51;
            // 
            // procuradoresTableAdapter
            // 
            this.procuradoresTableAdapter.ClearBeforeFill = true;
            // 
            // busquedapornombretxt
            // 
            this.busquedapornombretxt.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11.89565F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busquedapornombretxt.Location = new System.Drawing.Point(585, 64);
            this.busquedapornombretxt.Margin = new System.Windows.Forms.Padding(4);
            this.busquedapornombretxt.Name = "busquedapornombretxt";
            this.busquedapornombretxt.Size = new System.Drawing.Size(289, 33);
            this.busquedapornombretxt.TabIndex = 53;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 29);
            this.label1.TabIndex = 54;
            this.label1.Text = "Busqueda por ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 13.77391F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(601, 31);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 29);
            this.label2.TabIndex = 55;
            this.label2.Text = "Busqueda por nombre ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(585, 104);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 59);
            this.button1.TabIndex = 56;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(737, 104);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(137, 59);
            this.button2.TabIndex = 57;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // procuradorIdTextBox
            // 
            this.procuradorIdTextBox.Location = new System.Drawing.Point(12, 141);
            this.procuradorIdTextBox.Name = "procuradorIdTextBox";
            this.procuradorIdTextBox.Size = new System.Drawing.Size(100, 22);
            this.procuradorIdTextBox.TabIndex = 58;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 716);
            this.Controls.Add(this.procuradorIdTextBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.busquedapornombretxt);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtIDprocurador);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form6";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.procuradoresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUEVO_GABINETE_DE_ABOGADOSDataSet14)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtIDprocurador;
        private NUEVO_GABINETE_DE_ABOGADOSDataSet14 nUEVO_GABINETE_DE_ABOGADOSDataSet14;
        private System.Windows.Forms.BindingSource procuradoresBindingSource;
        private NUEVO_GABINETE_DE_ABOGADOSDataSet14TableAdapters.ProcuradoresTableAdapter procuradoresTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn procuradorIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoProcuradorDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox busquedapornombretxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox procuradorIdTextBox;
    }
}